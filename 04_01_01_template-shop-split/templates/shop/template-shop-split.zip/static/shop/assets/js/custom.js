$('#sort-product').change(function() {
    // Lấy giá trị đã chọn từ thẻ <select>
    let selectedValue = $(this).val();
        // Chuyển hướng tới trang mới dựa trên giá trị đã chọn
        window.location.href = selectedValue;
});